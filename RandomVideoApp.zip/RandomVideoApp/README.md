# Random Video App — সেটআপ গাইড (ধাপে ধাপে)

## ফোল্ডার স্ট্রাকচার
```
RandomVideoApp/
  signaling-server/   -> এইটা Render.com এ আলাদা করে হোস্ট হবে
    index.js
    package.json
  mobile-app/          -> এইটা আপনার Expo প্রজেক্টের ভেতরে বসবে
    App.js
    screens/
      HomeScreen.js
      VideoCallScreen.js
```

---

## ধাপ ১: Signaling Server ডিপ্লয় করুন (Render.com - ফ্রি)

1. GitHub-এ একটা নতুন repo বানান, নাম দিন `signaling-server`
2. `signaling-server/index.js` আর `signaling-server/package.json` — এই দুইটা ফাইল সেই repo-তে আপলোড করুন
3. https://render.com এ গিয়ে GitHub দিয়ে সাইন আপ করুন
4. "New +" -> "Web Service" -> আপনার `signaling-server` repo সিলেক্ট করুন
5. সেটিংস:
   - Build Command: `npm install`
   - Start Command: `npm start`
   - Instance Type: Free
6. Deploy করুন। কিছুক্ষণ পর একটা URL পাবেন, যেমন:
   `https://signaling-server-xxxx.onrender.com`
7. **এই URL কপি করে রাখুন — পরের ধাপে লাগবে**

⚠️ ফ্রি টিয়ারে সার্ভার ১৫ মিনিট নিষ্ক্রিয় থাকলে ঘুমিয়ে যায়, প্রথম রিকোয়েস্টে ৩০-৫০ সেকেন্ড দেরি হতে পারে। এটা স্বাভাবিক।

---

## ধাপ ২: আপনার Expo প্রজেক্টে (RandomVideoApp) কোড বসান

আপনার RandomVideoApp প্রজেক্টের root-এ গিয়ে এই প্যাকেজগুলো ইন্সটল করুন:

```bash
npx expo install react-native-webrtc
npm install socket.io-client
```

তারপর:
- `mobile-app/App.js` -> কপি করে আপনার প্রজেক্টের root-এ `App.js` হিসেবে বসান (আগেরটা রিপ্লেস করবে)
- `mobile-app/screens/` পুরো ফোল্ডার -> আপনার প্রজেক্টের root-এ কপি করুন

`VideoCallScreen.js` ফাইলে গিয়ে এই লাইনটা এডিট করুন:
```js
const SIGNALING_SERVER_URL = "https://your-signaling-server.onrender.com";
```
এখানে ধাপ ১-এ পাওয়া আপনার আসল Render URL বসান।

---

## ধাপ ৩: app.json / app.config.js এ প্লাগইন যোগ করুন

`react-native-webrtc` একটা native module — তাই **Expo Go দিয়ে চলবে না**, dev client বা EAS build লাগবে (যেটা আপনি এমনিতেও করছেন)।

`app.json`-এ camera/microphone পারমিশন ও প্লাগইন যোগ করুন:

```json
{
  "expo": {
    "plugins": [
      [
        "react-native-webrtc",
        {
          "cameraPermission": "একটা ভিডিও কল করার জন্য ক্যামেরা এক্সেস দরকার।",
          "microphonePermission": "একটা ভিডিও কল করার জন্য মাইক্রোফোন এক্সেস দরকার।"
        }
      ]
    ],
    "android": {
      "permissions": ["CAMERA", "RECORD_AUDIO"]
    }
  }
}
```

---

## ধাপ ৪: EAS Build চালান

```bash
eas build --platform android --profile preview
```

(আগের মতোই — `EAS_SKIP_AUTO_FINGERPRINT=1` লাগলে ব্যবহার করবেন)

---

## গুরুত্বপূর্ণ নোট
- `react-native-webrtc` থাকার কারণে **preview build APK-তে টেস্ট করতে হবে**, Expo Go দিয়ে চলবে না
- খুব কড়া NAT/ফায়ারওয়ালের পেছনে থাকা দুইজন ইউজারের মধ্যে কানেকশনের জন্য TURN সার্ভার লাগতে পারে (`VideoCallScreen.js`-এ কমেন্ট করা আছে কীভাবে যোগ করবেন)
- এই সংস্করণটা বেসিক — রিপোর্ট/ব্লক ফিচার, জেন্ডার ফিল্টার, চ্যাট মেসেজিং ইত্যাদি পরে ধাপে ধাপে যোগ করা যাবে
